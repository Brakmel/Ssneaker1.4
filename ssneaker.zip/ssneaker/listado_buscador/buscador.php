<?php 
$conexion=mysqli_connect("localhost","root","","bdssneaker");




$buscardor=mysqli_query($conexion,"SELECT * FROM zapatilla WHERE nombre_zapatilla LIKE LOWER('%".$_POST["buscar"]."%')"); 

 while($resultado = mysqli_fetch_assoc($buscardor)){ 
?>

<div class="">
<div class="">
<img height="" src="data:image/jpg;base64,<?php echo base64_encode($resultado['foto_zapatilla']); ?>"/>
  <div class="">
    <p class=""><?php echo $resultado["nombre_zapatilla"]; ?></p>
    <div class="">
      <div class="">
      </form>

      </div>
      <small class="text-muted"><?php echo $resultado["descripcion"]; ?></small>
    </div>
  </div>
</div>
</div>


<?php } ?>
